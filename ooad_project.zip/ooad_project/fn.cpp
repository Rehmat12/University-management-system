#include "fn.h"

void fn::add()         //To add a new book
{
	int m, n, k;
	ifstream f1;
	f1.open("book1.txt");

	cout << "\n\nEnter the book name   :";
	cin >> name;
	cout << "Enter writter name    :";
	cin >> wn;
	cout << "Enter the book code   :";
	cin >> code;
	cout << "Enter the no. of copy :";
	cin >> copy;


	char c[30][30] = { '\0' }, d[30][30] = { '\0' };
	int e[30] = { 0 }, r[30] = { 0 }, t[30] = { 0 };
	int p[30] = { 0 };
	int i = 0;
	while (!f1.eof())
	{
		f1 >> c[i];
		f1 >> d[i];
		f1 >> r[i];
		f1 >> p[i];
		i++;
	}
	f1.close();
	strcpy_s(c[i-1], 30, name);
	strcpy_s(d[i-1], 30, wn);
	r[i-1] = code;
	p[i-1] = copy;
	cout << "\n\nNew Book Has Been Added!!!\n\n" << endl;
	ofstream outf("book1.txt");
	for (int t = 0; t < i; t++)
	{
		outf << c[t] << "\t" << d[t] << "\t" << r[t] << "\t" << p[t] << endl;
	}
	z++;
}

void fn::delete1()         //To delete a copy of book from list
{

	int j;


	cout << "\nPlease enter the book code:";
	cin >> j;

	ifstream f6;
	f6.open("book1.txt");


	char c[30][30] = { '\0' }, d[30][30] = { '\0' };
	int e[30] = { 0 }, r[30] = { 0 }, t[30] = { 0 };
	int p[30] = { 0 };
	int i = 0;
	if (f6.is_open())
	{
		while (!f6.eof())
		{
			f6 >> c[i];
			f6 >> d[i];
			f6 >> r[i];
			f6 >> p[i];
			i++;
		}
		int flag = 0;
		for (int t = 0; t < i; t++)
		{
			if (r[t] == j)
			{
				p[t]--;
				flag = 1;
				break;
			}
		}
		if (flag == 1)
		{
			cout << "\n\n\t\tCopy Of Book has been Deleted.\n";
			ofstream outf("book1.txt");
			for (int t = 0; t < i; t++)
			{
				outf << c[t] << "\t" << d[t] << "\t" << r[t] << "\t" << p[t] << endl;
			}
		}
		else
		{
			cout << "Not available copy." << endl;
		}
		f6.close();
	}
	else
	{
		throw 121;
	}

}

void fn::plus()           //To add a copy of book to list
{
	int j;


	cout << "\nPlease enter the book code:";
	cin >> j;

	ifstream f6;
	f6.open("book1.txt");


	char c[30][30] = { '\0' }, d[30][30] = { '\0' };
	int e[30] = { 0 }, r[30] = { 0 }, t[30] = { 0 };
	int p[30] = { 0 };
	int i = 0;
	if (f6.is_open())
	{
		while (!f6.eof())
		{
			f6 >> c[i];
			f6 >> d[i];
			f6 >> r[i];
			f6 >> p[i];
			i++;
		}
		int flag = 0;
		for (int t = 0; t < i; t++)
		{
			if (r[t] == j)
			{
				p[t]++;
				flag = 1;
				break;
			}
		}
		if (flag == 1)
		{
			cout << "\n\n\t\tCopy Of Book has been Added.\n";
			ofstream outf("book1.txt");
			for (int t = 0; t < i; t++)
			{
				outf << c[t] << "\t" << d[t] << "\t" << r[t] << "\t" << p[t] << endl;
			}
		}
		else
		{
			cout << "Not available copy." << endl;
		}
		f6.close();
	}
	else
	{
		throw 121;
	}

}

void fn::display()          //To show the book list
{

	ifstream f3;
	f3.open("book1.txt");
	f3.seekg(0);

	char a;

	cout << "\n\n";
	cout << "\t*************** BOOK LIST ***************";
	cout << "\n\n";
	cout << "Bookname" << "\t" << "Writter" << "\t" << "Code" << "\t" << "Copy" << endl;
	cout << "--------" << "\t" << "-------" << "\t" << "----" << "\t" << "----" << endl;

	while (f3)
	{
		f3.get(a);
		cout << a;
	}
	f3.close();
}

void fn::srch()          //To search a book with its code from list
{
	int i, j, k = 0;

	cout << "\nPlease enter the Book code: ";
	cin >> j;

	ifstream f4;
	f4.open("book1.txt");

	char c[20], d[20];
	int n, p;

	while (!f4.eof())
	{
		f4 >> c;
		f4 >> d;
		f4 >> n;
		f4 >> p;

		if (n == j)
		{
			cout << "  Book name      : " << c << endl;
			cout << "  Writter name   : " << d << endl;
			cout << "  Book code      : " << n << endl;
			cout << "  Available copy : " << p << endl << endl;
		
			k++;
		}
		if (k == 1)
			break;
	}

}

