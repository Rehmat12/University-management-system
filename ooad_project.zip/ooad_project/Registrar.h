#pragma once
#include"Departments.h"
class Registrar : public Departments
{
public:
	char * reg;
	char *  password;
	Registrar();
	virtual ~Registrar();
	void fine();
	void addf();
	void choice();
	virtual void adds()
	{

	}
	virtual void lib()
	{

	}
	virtual void dels()
	{

	}
	void change();
	int check(char[50][14], int)
	{
		return 0;
	}
	virtual void input();
	virtual int check();
	int pass();
};

