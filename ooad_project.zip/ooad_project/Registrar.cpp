#include "Registrar.h"


Registrar::Registrar()
{
	reg = new char[100];

	password = new char[100];
	for (int i = 0; i < 100; i++)
	{
		reg[i] = '\0';
		password[i] = '\0';
	}
}


void Registrar::input()
{
	cout << "\n\n\t\tEnter Registration No :: ";
	cin >> reg;
	cout << "\n\n\t\tEnter password :: ";
	cin >> password;
}

void Registrar::fine()
{
	char temp[50][50] = { '\0' }, pass[50][50] = { '\0' };
	int temp1[50] = { '\0' }, fine[50] = { 0 };
	ifstream inf("reg.txt");
	int i = 0;
	while (!inf.eof())
	{
		inf >> temp[i];
		inf >> pass[i];
		inf >> temp1[i];
		inf >> fine[i];
		i++;
	}
	int flag = 0;
	for (int t = 0; t < i - 1; t++)
	{
		if (strcmp(reg, temp[t]) == 0)
		{
			temp1[t] = temp1[t] + 1;
			flag = 1;
			break;
		}
	}
	inf.close();
	ofstream outf("reg.txt");
	for (int t = 0; t < i - 1; t++)
	{
		outf << temp[t] << endl;
		outf << pass[t] << endl;
		if (temp[t] == '\0')
			break;
		outf << temp1[t] << endl;
		outf << fine[t] << endl;
	}
}

void Registrar::change()
{
	char temp[50][50] = { '\0' }, pass[50][50] = { '\0' }, extra[50] = { '\0' }, extra1[50] = { '\0' };
	int temp1[50] = { '\0' }, fine[50] = { 0 };
	ifstream inf("reg.txt");
	int i = 0;
	while (!inf.eof())
	{
		inf >> temp[i];
		inf >> pass[i];
		inf >> temp1[i];
		inf >> fine[i];
		i++;
	}
	int x = i;
	i = 0;
	int flag = 0;

	for (int i = 0; i < x; i++)
	{
		if (strcmp(reg, temp[i]) == 0)
		{
			cout << "Enter Old Password  : ";
			cin >> extra;
			if (strcmp(extra, pass[i]) == 0)
			{
				cout << "Enter New Password  : ";
				cin >> extra1;
				strcpy_s(pass[i], 20, extra1);
				flag = 1;
				cout << "\n\n\t\tPassword Changed!!!\n\n\n";
				break;
			}
		}
	}
	if (flag == 1)
	{
		ofstream outf("reg.txt");
		for (int t = 0; t < x - 1; t++)
		{
			outf << temp[t] << endl;
			outf << pass[t] << endl;
			outf << temp1[t] << endl;

			outf << fine[t] << endl;
		}
	}
	else
	{
		throw 403;
	}
}

void Registrar::choice()
{
	char temp[50][14] = { '\0' }, pass[50][20] = { '\0' };
	int temp1[50] = { '\0' }, fine[50] = { 0 };
	ifstream inf("reg.txt");
	int i = 0;
	while (!inf.eof())
	{
		inf >> temp[i];
		inf >> pass[i];
		inf >> temp1[i];
		inf >> fine[i];
		i++;
	}
		int x = i;
		i = 0;
		int flag = 0;

		for (int i = 0; i < x; i++)
		{
			if (strcmp(reg, temp[i]) == 0)
			{
				cout << "Registration No : " << temp[i] << endl;
				cout << "Issued Slips : " << temp1[i] << endl;
				cout << "Total Fine : " << fine[i] << endl;
				break;
			}
		}
}

void Registrar::addf()
{
	char temp[50][14] = { '\0' }, pass[50][20] = { '\0' };
	int temp1[50] = { '\0' };
	int fine[50] = { 0 };
	ifstream inf("reg.txt");
	int i = 0;
	while (!inf.eof())
	{
		inf >> temp[i];
		inf >> pass[i];
		inf >> temp1[i];
		inf >> fine[i];
		i++;
	}
	inf.close();
	int flag = 0;
	for (int t = 0; t < i; t++)
	{
		if (strcmp(reg, temp[t]) == 0)
		{
			if (temp1[t]>2)
			{
				fine[t] = (250)*(temp1[t] - 2);
				break;
			}
		}
	}
	ofstream outf("reg.txt");
	for (int t = 0; t < i - 1; t++)
	{
		outf << temp[t] << endl;
		outf << pass[t] << endl;
		outf << temp1[t] << endl;

		outf << fine[t] << endl;
	}

}
int Registrar::check()
{
	char temp[50][14] = { '\0' }, pass[50][20] = { '\0' };
	int temp1[50] = { 0 }, fine = 0;
	ifstream inf("reg.txt");
	int i = 0;
	if (inf.is_open())
	{
		while (!inf.eof())
		{
			inf >> temp[i];
			inf >> pass[i];
			inf >> temp1[i];
			inf >> fine;
			i++;
		}
		int x = i;
		i = 0;
		int flag = 0;

		for (int i = 0; i < x; i++)
		{
			if (strcmp(reg, temp[i]) == 0)
			{
				flag = 1;
				break;
			}
		}
		if (flag == 1)
		{
			cout << "\n\n\t\tHere Is Your Slip Now You Can Enter University.\n\n" << endl;
			return 1;
		}
		else
		{
			throw 401;
		}

		inf.close();
	}
	else
	{
		throw 121;
	}
}


int Registrar::pass()
{
	char temp[50][50] = { '\0' }, pass[50][50] = { '\0' };
	int temp1[50] = { 0 }, fine = 0;
	ifstream inf("reg.txt");
	int i = 0;
	while (!inf.eof())
	{
		inf >> temp[i];
		inf >> pass[i];
		inf >> temp1[i];
		inf >> fine;
		i++;
	}
	int x = i;
	i = 0;
	int flag = 0;

	for (int i = 0; i < x; i++)
	{
		if (strcmp(reg, temp[i]) == 0)
		{
			if (strcmp(password, pass[i]) == 0)
			{
				flag = 1;
				break;
			}
		}
	}
	if (flag == 1)
	{
		cout << "\n\n\t\tAcces Guarented.\n\n" << endl;
		return 1;
	}
	else
	{
		throw 401;
	}

	inf.close();
}

Registrar::~Registrar()
{
}
