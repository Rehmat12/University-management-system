#include "liberary.h"


liberary::liberary()
{
}


liberary::~liberary()
{
}
