#pragma once
#include<fstream>
#include<iostream>
using namespace std;
class Departments
{
public:
	virtual void input() = 0;
	Departments();
	~Departments();
};

