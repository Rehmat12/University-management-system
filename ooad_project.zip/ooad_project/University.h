#pragma once
#include<iostream>
using namespace std;
#include"Registrar.h"
#include"fn.h"
#include"FrontOffice.h"
#include<fstream>
#include<conio.h>

class University
{
	char * reg;
	char *pass;
	Registrar *obj1;
	FrontOffice *obj3;
public:
	void input();
	virtual void input1();
	int  check();
	int  password();
	void choice();

	void change();
	
	void  fine();
	University();
	~University();
};

