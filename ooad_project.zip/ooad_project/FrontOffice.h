#pragma once
#include"Registrar.h"
class FrontOffice : public Registrar
{
public:

	FrontOffice(); 
	int check();
	int check(char[50][14], int)
	{
		return 0;
	}
	void display();
	void input();
	~FrontOffice();
};

