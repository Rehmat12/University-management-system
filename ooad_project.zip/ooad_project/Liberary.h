#pragma once

#include<iostream>
using namespace std;
#include<fstream>

#include<iomanip>
#include<conio.h>
#include<string.h>

class liberary
{
protected:
	char name[25];
	char wn[25];
	int code;
	int copy;
public:
	liberary();
	~liberary();
};
