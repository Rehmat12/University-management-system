#include "FrontOffice.h"


FrontOffice::FrontOffice()
{
	
}

void FrontOffice::input()
{
	cout << "\n\n\t\tEnter Registration No :: ";
	cin >> reg;
}
void FrontOffice::display()
{
}
int FrontOffice::check()
{
	char temp[50][50] = { '\0' }, pass[50][50] = { '\0' };
	int temp1[50] = { 0 }, fine = 0;
	ifstream inf("reg.txt");
	int i = 0;
	if (inf.is_open())
	{
		while (!inf.eof())
		{
			inf >> temp[i];
			inf >> pass[i];
			inf >> temp1[i];
			inf >> fine;
			i++;
		}
		int x = i;
		i = 0;
		int flag = 0;

		for (int i = 0; i < x; i++)
		{
			if (strcmp(reg, temp[i]) == 0)
			{
				flag = 1;
				break;
			}
		}
		if (flag == 1)
		{
			return 1;
		}
		else
		{
			throw 402;
		}

		inf.close();
	}
	else
	{
		throw 121;
	}
}

FrontOffice::~FrontOffice()
{
}
