#include "Admin.h"


Admin::Admin()
{
	reg = new char[100];

	pass = new char[100];
	for (int i = 0; i < 100; i++)
	{
		reg[i] = '\0';
		pass[i] = '\0';
	}
}

void Admin::input()
{
	cout << "Enter Admin_Registration No :: ";
	cin >> reg;
	cout << "\t\tEnter password :: ";
	cin >> pass;
}
void Admin::lib()
{
	cout << "Enter Admin_Registration No :: ";
	cin >> reg;
	cout << "\t\tEnter password :: ";
	cin >> pass;
}
void Admin::dels()
{

	char temp[50][14] = { '\0' }, pass[50][20] = { '\0' }, extra[20] = { '\0' };
	int temp1[50] = { '\0' }, fine[50] = { 0 };
	char tem[50][14] = { '\0' }, pas[50][20] = { '\0' };
	int tem1[50] = { '\0' }, fine1[50] = { 0 };
	ifstream inf("reg.txt");
	int i = 0;
	if (inf.is_open())
	{
		while (!inf.eof())
		{
			inf >> temp[i];
			inf >> pass[i];
			inf >> temp1[i];
			inf >> fine[i];
			i++;
		}
		cout << "\n\t\tEnter Student Registration No to be Deleted : ";
		cin >> extra;
		int flag = 0;
		int x = 0;
		for (int t = 0; t < i - 1; t++)
		{
			if (strcmp(extra, temp[t]) != 0)
			{
						strcpy_s(tem[x], 14, temp[t]);
						strcpy_s(pas[x], 20, pass[t]);
						tem1[x] = temp1[t];
						fine1[x] = fine[t];
						x++;
						flag = 1;
			}

		}
		if (flag == 0)
		{
			cout << "No Record Found...." << endl << endl;
		}
		inf.close();
		if (flag == 1)
		{
			cout << "Student Has Been Deleted...." << endl << endl;
			ofstream outf("reg.txt");
			for (int t = 0; t < i - 2; t++)
			{
				outf << tem[t] << endl;
				outf << pas[t] << endl;
				if (temp[t] == '\0')
					break;
				outf << tem1[t] << endl;
				outf << fine1[t] << endl;
			}
		}
	}
	else
	{
		throw 121;
	}
}

void Admin::adds()
{
	char temp[50][14] = { '\0' }, pass[50][20] = { '\0' };
	int temp1[50] = { 0 };
	int fine[50] = { 0 };
	ifstream inf("reg.txt");
	int i = 0;
	if (inf.is_open())
	{
		while (!inf.eof())
		{
			inf >> temp[i];
			inf >> pass[i];
			inf >> temp1[i];
			inf >> fine[i];
			i++;
		}
		inf.close();
		int flag = 0;
		cout << "\n\t\tEnter New Student Registration No : ";
		cin >> temp[i - 1];
		cout << "\n\t\tEnter New Student Password : ";
		cin >> pass[i - 1];
		temp1[i - 1] = 0;
		fine[i - 1] = 0;
		ofstream outf("reg.txt");
		for (int t = 0; t < i; t++)
		{
			outf << temp[t] << endl;
			outf << pass[t] << endl;
			outf << temp1[t] << endl;

			outf << fine[t] << endl;
		}
		cout << "New Student Has Been Added. \n\tUserName : " << temp[i - 1] << "\n\tPassword : "<<pass[i-1]<< endl;
	}
	else
	{
		throw 121;
	}
}

int Admin::check()
{

	char temp[50] = { '\0' }, temp2[50] = { '\0' };
	ifstream inf("admin.txt");
	if (inf.is_open())
	{
		while (!inf.eof())
		{
			inf >> temp;
			inf >> temp2;
			break;

		}
		int flag = 0;

		if (strcmp(reg, temp) == 0)
		{
			if (strcmp(pass, temp2) == 0)
			{
				flag = 1;
			}
		}
		if (flag == 1)
		{
			return 1;
		}
		else
		{
			cout << "\n\n\t\tInvalid Admin_Registration Or Password No Entered...\n\n" << endl;
			return 0;
		}

		inf.close();
	}
	else
	{
		throw 121;
	}
}

Admin::~Admin()
{
}
