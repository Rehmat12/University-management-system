#pragma once
#include<fstream>
#include"liberary.h"
class fn : public liberary
{
	int z;
public:
	void add();
	void delete1();
	void plus();
	void display();
	void initial(){ z = 0; }
	void srch();
};
