#include "Departments.h"


Departments::Departments()
{
}


Departments::~Departments()
{
}
