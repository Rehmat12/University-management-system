#include "University.h"


University::University()
{
	obj1 = new Registrar;
	obj3 = new FrontOffice;
}


void University::change()
{
	obj1->change();
}

int University::password()
{
	return	obj1->pass();
}


void University::choice()
{
	obj1->choice();
}

void University::input()
{
	obj3->input();
}

void University::input1()
{
	obj1->input();
}

void University::fine()
{
	obj3->fine();
	obj3->addf();
}

int University::check()
{
	return obj3->check();
}

University::~University()
{
}
