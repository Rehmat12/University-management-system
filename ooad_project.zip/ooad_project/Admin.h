#pragma once
#include "Registrar.h"
#include "fn.h"
class Admin :
	public Registrar
{
	char *reg;
	char * pass;
public:
	int check();

	void adds();
	void lib();
	void dels();
	void input();
	Admin();
	~Admin();
};

