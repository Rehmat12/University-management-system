#include "Registrar.h"
#include "FrontOffice.h"
#include "University.h"
#include "fn.h"
#include "Admin.h"
int main()
{
	char x[100] = { '\0' }, y[100] = { '\0' };
	University obj;
	cout << "\n\n\t\t______________________________________\n\n\t\t";
	cout << "Welcome To University Managment System.";
	cout << "\n\n\t\t______________________________________\n\n\t\t";
Start:
	cout << "\n\t___________________________________\n\n\t";
	cout << "1 for Student OR 2 for Admin 3 for exit : "; 
	cin >> y;
	cout << "\n\t___________________________________\n\n\n\t";
	
	try{
		if (y[0] == '1' && y[1] =='\0')
		{
			start1:
			cout << "\n\n\t\tPress 1 for Slip OR 2 for Login : ";
			cin >> x;
			if (x[0] == '1')
			{

				obj.input();

				int y = obj.check();

				if (y)
				{
					cout << "\n\n\t\tHere Is Your Slip Now You Can Enter University.\n\n" << endl;
					obj.fine();
					goto Start;
				}
			}

			else if (x[0] == '2'&&x[1] == '\0')
			{
				char choice = '\0';
				obj.input1();
				int y = obj.password();
				if (y)
				{
				again:
					int i = 0;
					cout << "\n\n\t\tPress 1 For go to See Your Data.  || 2 For Change Password || 3 For Exit : ";
					cin >> choice;
					cout << endl << endl;
					if (choice == '1')
					{
						obj.choice();

					}
					else if (choice == '2')
					{
						obj.change();

					}
					else if (choice == '3')
					{
						goto end;

					}
					else
					{
						goto again;
					}

					goto start1;
				}
				else
				{

				}

			}
			else
			{
				goto Start;
			}
		}
		else if (y[0] == '2'&& y[1] == '\0')
		{
			cout << "\n\n\t\t";
			Registrar *ptr = new Admin;
			ptr->input();
			int y = ptr->check();
			if (y)
			{
				char p[10] = { '\0' };
				cout << "\n\n\t\tLogin Approved....\n\n\t\t" << endl;
				while (1)
				{
					cout << "\t\tPress 1 for Add Students \n\t\t 2 for Delete Students \n\t\t 3 for Liberary \n\t\t 4 for exit : ";
					cin >> p;
					if (p[0] == '1'&&p[1] == '\0')
					{
						ptr->adds();
					}
					else if (p[0] == '2'&&p[1] == '\0')
					{
						ptr->dels();
					}
					else if (p[0] == '3'&&p[1] == '\0')
					{

						int i;

						fn f;
						f.initial();

						while (1)
						{

							cout << "\n\n***----- WELL COME TO LIBRARY MANAGEMENT PROGRAM -----***";
							cout << "\n\nWhat do you want to do?" << endl;
							cout << "\n1: Add a new book to the list.";
							cout << "\n2: Delete a  copy of book from list.";
							cout << "\n3: Add a copy of book to list.";
							cout << "\n4: See the book list.";
							cout << "\n5: Search a Book from list.";
							cout << "\n6: Exit ." << endl;
							cout << "\nInput your choice:";
							cin >> i;

							switch (i)
							{
							case 1:
							{
									  f.add();
									  break;
							}

							case 2:
							{
									  f.delete1();
									  break;
							}

							case 3:
							{
									  f.plus();
									  break;
							}

							case 4:
							{
									  f.display();
									  break;
							}

							case 5:
							{
									  f.srch();
									  break;
							}

							case 6:
							{
									  cout << "Thank you.";
									  break;
							}
							}

							if (i == 6)
								break;
						}
					}

					else if (p[0] == '4'&&p[1] == '\0')
					{
						break;
					}
					else
					{
						cout << "Please Select the correct option .... " << endl << endl;

					}
					cout << endl << endl << endl;
				}
			}



		}

					else if (y[0] == '3'&&y[1] == '\0')
					{
						goto end;
					}
		else
		{
			goto Start;
		}
	}
	catch (int y)
	{
		if (y == 401)
		{
			cout << endl << endl << "Invalid UserName Or Password." << endl << endl;
		}
		else if (y == 402)
		{
			cout << endl << endl << "Invalid UserName." << endl << endl;
		}
		else if (y == 403)
		{
			cout << endl << endl << "Wrong Password." << endl << endl;
		}
		else if (y == 121)
		{
			cout << endl << endl << "File Can't Be Open." << endl << endl;
		}
	}
	end:
	return 0;
	
}